--------------------
fakeData
--------------------
Author: Electrica <info@modx.kz>
--------------------

Компонент реализаует интеграцию https://github.com/fzaninotto/Faker#fakerproviderfile